SATTVAM Restaurant Website
===========================
हालको Location: ISKCON Banepa नजिक, बनेपा, काभ्रे
Phone: 9841108163
Email: binodsatyal4@gmail.com

index.html लाई browser मा खोलेर वेबसाइट हेर्न सकिन्छ।
Online publish गर्न domain + hosting चाहिन्छ।
वास्तविक location, Google Map, फोटो र opening hours पछि सजिलै अपडेट गर्न सकिन्छ।
